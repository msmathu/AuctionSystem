using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace AuctionSystem.Pages.Login.User_Login
{
    public class UserLoginModel : PageModel
    {
        public List<UserInfo> listUser = new List<UserInfo>();
        public UserInfo userInfo = new UserInfo();
        public String Success = "";
        public String errorMsg = "";
        public String name = "";
        public String name1 = "";
        public String Password = " ";



        [HttpGet]

        [HttpPost]
        public IActionResult OnPostUserLogin(UserInfo user)
        {


            String connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                String sql = "SELECT username, userpassword FROM userregistration WHERE TRIM(username) COLLATE Latin1_General_CI_AI = @Username AND TRIM(userpassword) COLLATE Latin1_General_CI_AI = @Userpassword";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Username", user.username.Trim());
                    command.Parameters.AddWithValue("@Userpassword", user.userpassword.Trim());
                    using (SqlDataReader reader = command.ExecuteReader())
                    {


                        if (reader.Read())
                        {
                            connection.Close();
                            return RedirectToPage("/CustomerHome/CustomerHome");
                        }
                        else
                        {
                            connection.Close();
                            errorMsg = "Login failed / invalid username or password";
                            return Page();
                        }

                    }
                }
            }

        }
    }
}
public class UserInfo
{
    public String id { get; set; }
    public String username { get; set; }
    public String userpassword { get; set; }
    public String useremail { get; set; }
    public String userphone { get; set; }

}
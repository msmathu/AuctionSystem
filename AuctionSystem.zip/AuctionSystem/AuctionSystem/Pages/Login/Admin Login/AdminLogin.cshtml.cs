using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Security.Principal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Identity;
using AuctionSystem.Pages.AdminHome.AdminProduct;

namespace AuctionSystem.Pages.Login.Admin_Login
{
    public class AdminLoginModel : PageModel
    {
        public List<AdminInfo> listAdmin = new List<AdminInfo>();
        public AdminInfo adminInfo = new AdminInfo();
        public String Success = "";
        public String errorMsg = "";
        public String name = "";
        public String name1 = "";
        public String Password = " ";



        [HttpGet]

        [HttpPost]
        public IActionResult OnPostAdminLogin(AdminInfo addmin)
        {
            if (addmin.adminname.Length == 0  || addmin.adminpassword.Length == 0)
            {
                errorMsg = "All the fields are required";
                
            }

            String connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                String sql = "SELECT adminname, adminpassword FROM adminregistration WHERE TRIM(adminname) COLLATE Latin1_General_CI_AI = @Adminname AND TRIM(adminpassword) COLLATE Latin1_General_CI_AI = @Adminpassword";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@Adminname", addmin.adminname.Trim());
                    command.Parameters.AddWithValue("@Adminpassword", addmin.adminpassword.Trim());
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                     

                        if (reader.Read())
                        {
                            connection.Close();
                            return RedirectToPage("/AdminHome/AdminHome");
                        }
                        else
                        {
                            connection.Close();
                            errorMsg = "Login failed / invalid adminname or password";
                            return Page();
                        }

                    }
                }
            }

        }
    }
}


public class AdminInfo
{
    public String id;
    public String adminname { get; set; }
    public String adminpassword { get; set; }
    public String adminemail { get; set; }
    public String adminphone { get; set; }
    
}
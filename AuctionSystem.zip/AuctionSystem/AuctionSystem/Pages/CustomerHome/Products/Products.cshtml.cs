using AuctionSystem.Pages.AdminHome.AdminProduct;
using AuctionSystem.Pages.CustomerHome.Bidding_Details;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Threading;

using System;
using System.Collections.Generic;
 

namespace AuctionSystem.Pages.CustomerHome.Products
{
    public class ProductsModel : PageModel
    {
        public List<ProductInfo> listProducts = new List<ProductInfo>();
        public List<BidInfo> listBidProducts = new List<BidInfo>();
        public BidInfo bidInfo = new BidInfo();
        public String errorMsg = "";
        public String productname1 = "";
        public String successMessage = "";

        public void OnGet()
        {

          

            //  productname = Request.Query["productname"];
            try
            {
                String connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM addProduct";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ProductInfo productInfo = new ProductInfo();
                                productInfo.id = "" + reader.GetInt32(0);
                                productInfo.productname = reader.GetString(1);
                                productInfo.productprice = " " + reader.GetInt32(2);
                                productInfo.bidstart = " " + reader.GetInt32(3);
                                productInfo.productimagefilename = reader.GetString(4);



                                listProducts.Add(productInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }





      public IActionResult OnPostSubmitBid(string bidamount, string name, string email, string phone, string address ,string productname,string productprice,string bidstart)
      {
            productname1 = name;
            

             try{

              string connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";

              using (SqlConnection connection = new SqlConnection(connectionString))
              {
                  connection.Open();
                  string sql = "INSERT INTO bidProduct (bidamount, name, email, phone, address,productname,productprice,bidstart) VALUES ( @bidamount, @name, @email, @phone, @address,@productname,@productprice,@bidstart)";

                  using (SqlCommand command = new SqlCommand(sql, connection))
                  {
                      
                      command.Parameters.AddWithValue("@bidamount", bidamount);
                      command.Parameters.AddWithValue("@name", name);
                      command.Parameters.AddWithValue("@email", email);
                      command.Parameters.AddWithValue("@phone", phone);
                      command.Parameters.AddWithValue("@address", address);
                        command.Parameters.AddWithValue("@productname", productname);
                        command.Parameters.AddWithValue("@productprice", productprice);
                        command.Parameters.AddWithValue("@bidstart", bidstart);

                        command.ExecuteNonQuery();

                        
                  }
              }
                    successMessage = "New Product Added ";
                
                // Optionally, you can redirect the user to a success page
                return RedirectToPage("/CustomerHome/Products/Products");
          }
          catch (Exception ex)
          {
              Console.WriteLine("Exception: " + ex.ToString());

              errorMsg = ex.Message;
          }

           

            // If there was an error, stay on the same page and display the error message
            return Page();
}


    }

 

}


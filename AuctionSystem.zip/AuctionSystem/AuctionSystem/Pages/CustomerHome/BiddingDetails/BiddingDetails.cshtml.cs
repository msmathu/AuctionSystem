using AuctionSystem.Pages.AdminHome.AdminProduct;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace AuctionSystem.Pages.CustomerHome.Bidding_Details
{
    public class BiddingDetailsModel : PageModel
    {
        public List<BidInfo> listBidProducts = new List<BidInfo>();
        public string errorMsg = "";

         public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM bidProduct";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                BidInfo bidInfo = new BidInfo();
                                bidInfo.id = "" + reader.GetInt32(0);
                                bidInfo.bidamount =" "+ reader.GetInt32(1);
                                bidInfo.name =  reader.GetString(2);
                                bidInfo.email =  reader.GetString(3);
                                bidInfo.phone = reader.GetString(4);
                                bidInfo.productname =  reader.GetString(6);
                                bidInfo.productprice =reader.GetString(7);
                                bidInfo.bidstart = reader.GetString(8);


                                listBidProducts.Add(bidInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errorMsg = ex.Message;

                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
        
    }
}

    public class BidInfo
    {
        public String id;
        public String productname;
        public String productprice;
        public String bidstart;
        public String bidamount;
        public String name;
        public String email;
        public String phone;
        public string address;
    }



using AuctionSystem.Pages.AdminHome.AdminProduct;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
 

 


namespace AuctionSystem.Pages.AdminHome.AddProducts
{
    public class AddProductModel : PageModel
    {

        


        public ProductInfo productInfo = new ProductInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public  String proImage =  "";



        
       

        public void OnGet()
        {

        }
         public void OnPost( ) 
          {
              productInfo.productname = Request.Form["productname"];
              productInfo.productprice = Request.Form["productprice"];
              productInfo.bidstart = Request.Form["bidstart"];
              productInfo.productimage = Request.Form.Files["productimage"];

            try
            {

               

                String connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";
                  using (SqlConnection connection = new SqlConnection(connectionString))
                  {
                      connection.Open();


                      String sql = "INSERT INTO addProduct" + "(productname,productprice,bidstart ,productimage ) VALUES " + "(@productname,@productprice,@bidstart ,@productimagefilename);";
                      using (SqlCommand command = new SqlCommand(sql, connection))
                      {
                          

                          
                            command.Parameters.AddWithValue("@productname", productInfo.productname);
                            command.Parameters.AddWithValue("@productprice", productInfo.productprice);
                            command.Parameters.AddWithValue("@bidstart", productInfo.bidstart);
                            productInfo.productimagefilename = productInfo.productimage.FileName;
                            command.Parameters.AddWithValue("@productimagefilename",productInfo.productimagefilename); // Assuming you want to store the file name in the database

                          proImage = productInfo.productimage.FileName;

                        command.ExecuteNonQuery();
                      }
                  }

              }
              catch (Exception ex)
              {
                  errorMessage = ex.Message;
                  return;
              }

              productInfo.productname = "";
              productInfo.productprice = "";
              productInfo.bidstart = "";
 



              successMessage = "New Product Added ";

             // Response.Redirect("/AdminHome/AdminProduct/AdminProduct");
          }

      }

        
    }


 
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AuctionSystem.Pages.AdminHome
{
    public class AdminHomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

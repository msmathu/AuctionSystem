using AuctionSystem.Pages.AdminHome.AdminProduct;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace AuctionSystem.Pages.AdminHome
{
    public class EditProductModel : PageModel
    {
         
        public ProductInfo productInfo = new ProductInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
            String id = Request.Query["id"];

            try
            {
                String connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM addProduct WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                productInfo.id = "" + reader.GetInt32(0);
                                productInfo.productname = reader.GetString(1);
                                productInfo.productprice = " " + reader.GetInt32(2);
                                productInfo.bidstart = " " + reader.GetInt32(3);
                            }
                        }
                    }
                }
            }


     
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                Console.WriteLine("Exception: " + ex.ToString());
                return;
            }
        }



        public void OnPost()
        {

            productInfo.id = Request.Form["id"];
            productInfo.productname = Request.Form["productname"];
            productInfo.productprice = Request.Form["productprice"];
            productInfo.bidstart = Request.Form["bidstart"];

            if (productInfo.id.Length == 0 || productInfo.productname.Length == 0 || productInfo.productprice.Length == 0 || productInfo.bidstart.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            


            try
            {
                String connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();


                    String sql = "UPDATE addProduct SET productname=@productname, productprice=@productprice, bidstart=@bidstart  WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@productname",  productInfo.productname);
                        command.Parameters.AddWithValue("@productprice", productInfo.productprice);
                        command.Parameters.AddWithValue("@bidstart",  productInfo.bidstart);
                        command.Parameters.AddWithValue("@id", productInfo.id);



                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }

            successMessage = "Product edited successfully";

          //  Response.Redirect("/Clients/Index");
        }
    }
    }


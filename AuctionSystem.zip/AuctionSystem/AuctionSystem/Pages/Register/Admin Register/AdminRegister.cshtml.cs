using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace AuctionSystem.Pages.Register.Admin_Register
{
    
    public class AdminRegisterModel : PageModel
    {
       public AdminInfo adminInfo = new AdminInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
        }
        public void OnPost()
        {
             

            adminInfo.adminname = Request.Form["adminname"];
            adminInfo.adminpassword = Request.Form["adminpassword"];
            adminInfo.adminemail = Request.Form["adminemail"];
            adminInfo.adminphone = Request.Form["adminphone"];

            if (adminInfo.adminname.Length == 0 || adminInfo.adminpassword.Length == 0 ||
                     adminInfo.adminemail.Length == 0 || adminInfo.adminphone.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            //save the client into the database
            try
            {
                String connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();


                    String sql = "INSERT INTO adminregistration" + "(adminname,adminpassword,adminemail,adminphone) VALUES " + "(@adminname,@adminpassword,@adminemail,@adminphone);";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@adminname", adminInfo.adminname);
                        command.Parameters.AddWithValue("@adminpassword", adminInfo.adminpassword);
                        command.Parameters.AddWithValue("@adminemail", adminInfo.adminemail);
                        command.Parameters.AddWithValue("@adminphone", adminInfo.adminphone);

                        command.ExecuteNonQuery();
                    }
                }

            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            adminInfo.adminname = "";
            adminInfo.adminpassword = "";
            adminInfo.adminemail = " ";
            adminInfo.adminphone = " ";
            
            successMessage = "New Admin Added ";

           // Response.Redirect("/Clients/Index");
        }



    }
     
    
}

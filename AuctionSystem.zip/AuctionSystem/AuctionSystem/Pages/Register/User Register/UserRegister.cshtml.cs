using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace AuctionSystem.Pages.Register.User_Register
{
    public class UserRegisterModel : PageModel
    {
        public UserInfo userInfo = new UserInfo();
        public String errorMessage = "";
        public String successMessage = "";
        public void OnGet()
        {
        }

        public void OnPost()
        {


            userInfo.username = Request.Form["username"];
            userInfo.userpassword = Request.Form["userpassword"];
            userInfo.useremail = Request.Form["useremail"];
            userInfo.userphone = Request.Form["userphone"];

            

           if(userInfo.username.Length == 0 || userInfo.userphone.Length ==0 || userInfo.useremail.Length ==0 || userInfo.userpassword.Length == 0)
            {

            
                errorMessage = "All the fields are required";
                return;
            }

            //save the client into the database
            try
            {
                String connectionString = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=AuctionSystem;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();


                    String sql = "INSERT INTO userregistration" + "(username,userpassword,useremail,userphone) VALUES " + "(@username,@userpassword,@useremail,@userphone);";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@username", userInfo.username);
                        command.Parameters.AddWithValue("@userpassword", userInfo.userpassword);
                        command.Parameters.AddWithValue("@useremail", userInfo.useremail);
                        command.Parameters.AddWithValue("@userphone", userInfo.userphone);

                        command.ExecuteNonQuery();
                    }
                }

            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            userInfo.username = "";
            userInfo.userpassword = "";
            userInfo.useremail = "";
            userInfo.userphone = "";

            successMessage = "New User Added ";

            // Response.Redirect("/Clients/Index");
        }
    }
}

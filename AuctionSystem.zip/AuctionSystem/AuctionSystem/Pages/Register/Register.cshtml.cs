using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AuctionSystem.Pages.Register
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
